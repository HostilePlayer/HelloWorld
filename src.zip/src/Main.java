import java.util.Scanner;

public class Main
{
    static int personer;

    public void main(String[] args) {
        Ingredien[] ingredienser;

        Opskrift opskrift = new Opskrift();

        System.out.println("velkommen til din kage omregner");
        System.out.println("skriv hvor mange personer kagen er til");
        System.out.println("----------------------------------------");
        ingredienser = opskrift.getIngredienser();

        personer = new Scanner(System.in).nextInt();

        //TODO: Set antal personer for opskriften via en metode
        opskrift.setAntal(personer);

        System.out.println("----------------------------------------");


        for (Ingredien data : ingredienser) {
            System.out.println(data.getNavn() + " " + data.beregnKiloJoule() + "kj");
        }




        System.out.println("----------------------------------------");



    }
/*
    public int getPersoner() {

        return personer;
    }
    */
}
